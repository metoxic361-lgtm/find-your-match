import GlobalPulse from "./ui/global-pulse";

export default function Page() {
  return <GlobalPulse />;
}
