import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GlobalPulse — One platform, every timezone",
  description: "A globally localized, real-time digital platform foundation."
};

export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
