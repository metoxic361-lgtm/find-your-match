 "use client";

import { FormEvent, useEffect, useMemo, useState } from "react";

type Locale = "en" | "sw" | "es" | "fr" | "ar";

const copy: Record<Locale, Record<string, string>> = {
  en: {
    navFeatures: "Features", navAnalytics: "Analytics", navJoin: "Join",
    eyebrow: "Built for a world that never sleeps",
    hero: "One platform. Every timezone. Every language.",
    sub: "A responsive global experience designed for real-time participation, localized discovery, accessible interaction, and measurable growth.",
    primary: "Create your account", secondary: "Explore analytics",
    live: "LIVE SYSTEM", countries: "195 countries", languages: "7,100+ languages",
    zones: "24 time zones", realtime: "Real-time updates",
    featuresTitle: "Global by architecture, not by afterthought",
    featuresSub: "Core capabilities are designed around localization, performance, accessibility and live data from day one.",
    f1: "Global localization", f1d: "Locale-aware content, timezone handling, language switching and RTL-ready presentation.",
    f2: "Live intelligence", f2d: "WebSocket events and analytics endpoints provide a foundation for real-time dashboards.",
    f3: "Secure by default", f3d: "Helmet headers, CORS controls, rate limiting, parameterized SQL and centralized error handling.",
    f4: "Accessible everywhere", f4d: "Semantic landmarks, keyboard navigation, visible focus states and screen-reader labels.",
    analyticsTitle: "Live platform pulse", analyticsSub: "Illustrative telemetry from the platform API, refreshed without a full page reload.",
    users: "Active users", sessions: "Sessions", events: "Events/min", latency: "Median latency",
    joinTitle: "Join the global network", joinSub: "Create a profile with validation, localization and timezone detection.",
    name: "Full name", email: "Email address", locale: "Language", submit: "Create profile",
    footer: "GlobalPulse foundation • Built for resilient, inclusive digital experiences.",
    success: "Profile created successfully.", error: "Please check the form and try again."
  },
  sw: {
    navFeatures: "Vipengele", navAnalytics: "Takwimu", navJoin: "Jiunge",
    eyebrow: "Imejengwa kwa dunia isiyolala",
    hero: "Jukwaa moja. Saa zote. Lugha zote.",
    sub: "Uzoefu wa kimataifa unaowezesha ushiriki wa papo kwa papo, ugunduzi wa ndani, ufikivu na ukuaji unaopimika.",
    primary: "Fungua akaunti", secondary: "Angalia takwimu",
    live: "MFUMO LIVE", countries: "Nchi 195", languages: "Lugha 7,100+",
    zones: "Saa 24", realtime: "Masasisho ya papo kwa papo",
    featuresTitle: "Kimataifa kuanzia usanifu",
    featuresSub: "Vipengele vimeundwa kwa localization, kasi, accessibility na data ya moja kwa moja.",
    f1: "Localization ya kimataifa", f1d: "Maudhui kulingana na lugha, timezone na maandalizi ya RTL.",
    f2: "Akili ya papo kwa papo", f2d: "WebSockets na analytics hujenga msingi wa dashboards za moja kwa moja.",
    f3: "Usalama kwa chaguo-msingi", f3d: "Helmet, CORS, rate limiting, SQL salama na error handling.",
    f4: "Accessibility kila mahali", f4d: "Semantic HTML, keyboard navigation, focus states na screen-reader labels.",
    analyticsTitle: "Hali ya jukwaa live", analyticsSub: "Takwimu za mfano kutoka API ya jukwaa.",
    users: "Watumiaji hai", sessions: "Sessions", events: "Matukio/dak", latency: "Latency ya kati",
    joinTitle: "Jiunge na mtandao wa dunia", joinSub: "Unda wasifu kwa validation, lugha na timezone.",
    name: "Jina kamili", email: "Barua pepe", locale: "Lugha", submit: "Unda wasifu",
    footer: "GlobalPulse foundation • Imejengwa kwa uzoefu wa kidijitali unaojumuisha wote.",
    success: "Wasifu umeundwa.", error: "Kagua fomu ujaribu tena."
  },
  es: { navFeatures:"Funciones",navAnalytics:"Analítica",navJoin:"Unirse",eyebrow:"Creado para un mundo que nunca duerme",hero:"Una plataforma. Cada zona horaria. Cada idioma.",sub:"Una experiencia global preparada para participación en tiempo real, descubrimiento localizado, accesibilidad y crecimiento medible.",primary:"Crear cuenta",secondary:"Explorar analítica",live:"SISTEMA EN VIVO",countries:"195 países",languages:"7.100+ idiomas",zones:"24 zonas horarias",realtime:"Actualizaciones en tiempo real",featuresTitle:"Global desde la arquitectura",featuresSub:"Localización, rendimiento, accesibilidad y datos en vivo desde el primer día.",f1:"Localización global",f1d:"Contenido por idioma, zona horaria y presentación RTL.",f2:"Inteligencia en vivo",f2d:"WebSockets y analítica para paneles en tiempo real.",f3:"Seguro por defecto",f3d:"Cabeceras Helmet, CORS, límites de tasa y SQL parametrizado.",f4:"Accesible en todas partes",f4d:"HTML semántico, teclado y etiquetas para lectores de pantalla.",analyticsTitle:"Pulso de la plataforma",analyticsSub:"Telemetría ilustrativa de la API.",users:"Usuarios activos",sessions:"Sesiones",events:"Eventos/min",latency:"Latencia media",joinTitle:"Únete a la red global",joinSub:"Crea un perfil con validación, idioma y zona horaria.",name:"Nombre completo",email:"Correo electrónico",locale:"Idioma",submit:"Crear perfil",footer:"GlobalPulse foundation • Experiencias digitales resilientes e inclusivas.",success:"Perfil creado correctamente.",error:"Revisa el formulario e inténtalo de nuevo." },
  fr: { navFeatures:"Fonctions",navAnalytics:"Analytique",navJoin:"Rejoindre",eyebrow:"Conçu pour un monde qui ne dort jamais",hero:"Une plateforme. Chaque fuseau. Chaque langue.",sub:"Une expérience mondiale pour la participation en temps réel, la découverte locale, l'accessibilité et une croissance mesurable.",primary:"Créer un compte",secondary:"Voir les analyses",live:"SYSTÈME EN DIRECT",countries:"195 pays",languages:"7 100+ langues",zones:"24 fuseaux",realtime:"Mises à jour en temps réel",featuresTitle:"Mondial dès l'architecture",featuresSub:"Localisation, performance, accessibilité et données en direct dès le départ.",f1:"Localisation mondiale",f1d:"Contenu selon la langue, le fuseau et affichage RTL.",f2:"Intelligence en direct",f2d:"WebSockets et API d'analytique pour les tableaux de bord.",f3:"Sécurité par défaut",f3d:"Helmet, CORS, limitation de débit et SQL paramétré.",f4:"Accessible partout",f4d:"HTML sémantique, navigation clavier et labels lecteurs d'écran.",analyticsTitle:"Pouls de la plateforme",analyticsSub:"Télémétrie illustrative issue de l'API.",users:"Utilisateurs actifs",sessions:"Sessions",events:"Événements/min",latency:"Latence médiane",joinTitle:"Rejoignez le réseau mondial",joinSub:"Créez un profil avec validation, langue et fuseau horaire.",name:"Nom complet",email:"Adresse e-mail",locale:"Langue",submit:"Créer le profil",footer:"GlobalPulse foundation • Expériences numériques résilientes et inclusives.",success:"Profil créé.",error:"Vérifiez le formulaire et réessayez." },
  ar: { navFeatures:"الميزات",navAnalytics:"التحليلات",navJoin:"انضم",eyebrow:"مصمم لعالم لا ينام",hero:"منصة واحدة. كل المناطق الزمنية. كل اللغات.",sub:"تجربة عالمية للمشاركة الفورية والاكتشاف المحلي وإمكانية الوصول والنمو القابل للقياس.",primary:"إنشاء حساب",secondary:"استكشف التحليلات",live:"النظام مباشر",countries:"195 دولة",languages:"أكثر من 7100 لغة",zones:"24 منطقة زمنية",realtime:"تحديثات فورية",featuresTitle:"عالمي منذ التصميم",featuresSub:"التوطين والأداء وإمكانية الوصول والبيانات المباشرة من البداية.",f1:"توطين عالمي",f1d:"محتوى حسب اللغة والمنطقة الزمنية ودعم RTL.",f2:"ذكاء مباشر",f2d:"WebSockets وتحليلات للوحات المعلومات الفورية.",f3:"الأمان افتراضيًا",f3d:"Helmet وCORS وتحديد المعدل واستعلامات SQL آمنة.",f4:"إمكانية الوصول",f4d:"HTML دلالي وتنقل بلوحة المفاتيح وتسميات لقارئات الشاشة.",analyticsTitle:"نبض المنصة",analyticsSub:"بيانات توضيحية من واجهة API.",users:"المستخدمون النشطون",sessions:"الجلسات",events:"الأحداث/دقيقة",latency:"زمن الاستجابة",joinTitle:"انضم إلى الشبكة العالمية",joinSub:"أنشئ ملفًا مع التحقق واللغة والمنطقة الزمنية.",name:"الاسم الكامل",email:"البريد الإلكتروني",locale:"اللغة",submit:"إنشاء الملف",footer:"GlobalPulse foundation • تجارب رقمية مرنة وشاملة.",success:"تم إنشاء الملف.",error:"تحقق من النموذج وحاول مرة أخرى." }
};

const flags: Record<Locale,string> = { en:"EN", sw:"SW", es:"ES", fr:"FR", ar:"AR" };

export default function GlobalPulse() {
  const [locale, setLocale] = useState<Locale>("en");
  const [dark, setDark] = useState(true);
  const [stats, setStats] = useState({ users: 8421, sessions: 12944, events: 318, latency: 84 });
  const [form, setForm] = useState({ name:"", email:"", locale:"en" });
  const [message, setMessage] = useState("");
  const t = copy[locale];

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
    document.documentElement.dataset.theme = dark ? "dark" : "light";
  }, [locale, dark]);

  useEffect(() => {
    const tick = async () => {
      try {
        const res = await fetch("/api/v1/stats", { cache: "no-store" });
        if (res.ok) setStats(await res.json());
      } catch {}
    };
    tick();
    const id = setInterval(tick, 5000);
    return () => clearInterval(id);
  }, []);

  const bars = useMemo(() => [42,58,51,74,62,88,79,94,82,100,91,96], []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMessage("");
    if (form.name.trim().length < 2 || !/^\S+@\S+\.\S+$/.test(form.email)) {
      setMessage(t.error);
      return;
    }
    const res = await fetch("/api/v1/users", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ ...form, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone })
    });
    setMessage(res.ok ? t.success : t.error);
    if (res.ok) setForm({name:"",email:"",locale});
  }

  return (
    <main className="min-h-screen overflow-hidden">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-black/35 backdrop-blur-xl">
        <nav aria-label="Primary" className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <a href="#" className="flex items-center gap-3 font-black tracking-tight" aria-label="GlobalPulse home">
            <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-cyan-400 text-black">G</span>
            <span>Global<span className="text-fuchsia-400">Pulse</span></span>
          </a>
          <div className="hidden items-center gap-7 text-sm text-slate-300 md:flex">
            <a href="#features" className="hover:text-white">{t.navFeatures}</a>
            <a href="#analytics" className="hover:text-white">{t.navAnalytics}</a>
            <a href="#join" className="hover:text-white">{t.navJoin}</a>
          </div>
          <div className="flex items-center gap-2">
            <label className="sr-only" htmlFor="language">Language</label>
            <select id="language" value={locale} onChange={e=>{const l=e.target.value as Locale;setLocale(l);setForm(f=>({...f,locale:l}))}} className="rounded-xl border border-white/10 bg-white/5 px-2 py-2 text-xs outline-none">
              {Object.entries(flags).map(([k,v])=><option key={k} value={k} className="bg-slate-900">{v}</option>)}
            </select>
            <button aria-label="Toggle theme" onClick={()=>setDark(v=>!v)} className="rounded-xl border border-white/10 px-3 py-2 text-sm hover:bg-white/10">{dark?"☼":"☾"}</button>
          </div>
        </nav>
      </header>

      <section className="relative mx-auto max-w-7xl px-5 pb-20 pt-20 lg:px-8 lg:pt-28">
        <div className="absolute -left-32 top-0 -z-10 h-96 w-96 rounded-full bg-fuchsia-600/20 blur-3xl" />
        <div className="absolute right-0 top-32 -z-10 h-80 w-80 rounded-full bg-cyan-500/15 blur-3xl" />
        <div className="grid items-center gap-14 lg:grid-cols-[1.1fr_.9fr]">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/5 px-4 py-2 text-xs font-semibold text-emerald-300">
              <span className="size-2 animate-pulse rounded-full bg-emerald-400" /> {t.live}
            </div>
            <p className="mb-4 text-sm font-semibold uppercase tracking-[.24em] text-fuchsia-300">{t.eyebrow}</p>
            <h1 className="max-w-4xl text-5xl font-black leading-[.98] tracking-[-.05em] sm:text-6xl lg:text-7xl">{t.hero}</h1>
            <p className="mt-7 max-w-2xl text-lg leading-8 text-slate-300">{t.sub}</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#join" className="rounded-2xl bg-white px-6 py-3.5 font-bold text-slate-950 shadow-2xl shadow-fuchsia-500/10 hover:-translate-y-0.5">{t.primary}</a>
              <a href="#analytics" className="rounded-2xl border border-white/15 bg-white/5 px-6 py-3.5 font-bold hover:bg-white/10">{t.secondary}</a>
            </div>
            <div className="mt-10 grid max-w-xl grid-cols-3 gap-3">
              {[["195",t.countries],["7.1K+",t.languages],["24",t.zones]].map(([n,l])=><div key={l} className="rounded-2xl border border-white/10 bg-white/[.035] p-4"><strong className="text-xl">{n}</strong><p className="mt-1 text-xs text-slate-400">{l}</p></div>)}
            </div>
          </div>
          <div className="relative rounded-[2rem] border border-white/10 bg-white/[.04] p-5 shadow-2xl shadow-fuchsia-950/30 backdrop-blur-xl">
            <div className="rounded-[1.5rem] border border-white/10 bg-slate-950/70 p-5">
              <div className="flex items-center justify-between"><span className="text-sm text-slate-400">{t.analyticsTitle}</span><span className="text-xs text-emerald-300">● LIVE</span></div>
              <div className="mt-8 flex h-48 items-end gap-2">
                {bars.map((h,i)=><div key={i} className="group relative flex-1"><div style={{height:`${h}%`}} className="rounded-t-lg bg-gradient-to-t from-fuchsia-700 to-cyan-300 opacity-80 transition group-hover:opacity-100" /></div>)}
              </div>
              <div className="mt-6 grid grid-cols-2 gap-3">
                <Metric label={t.users} value={stats.users.toLocaleString()} />
                <Metric label={t.events} value={stats.events.toString()} />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="max-w-2xl"><p className="text-sm font-bold uppercase tracking-[.2em] text-fuchsia-300">01</p><h2 className="mt-3 text-4xl font-black">{t.featuresTitle}</h2><p className="mt-4 text-slate-400">{t.featuresSub}</p></div>
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          <Feature icon="◎" title={t.f1} body={t.f1d} />
          <Feature icon="⌁" title={t.f2} body={t.f2d} />
          <Feature icon="◈" title={t.f3} body={t.f3d} />
          <Feature icon="◇" title={t.f4} body={t.f4d} />
        </div>
      </section>

      <section id="analytics" className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="rounded-[2rem] border border-white/10 bg-white/[.035] p-6 lg:p-8">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="text-sm font-bold uppercase tracking-[.2em] text-cyan-300">02</p><h2 className="mt-3 text-3xl font-black">{t.analyticsTitle}</h2><p className="mt-2 text-slate-400">{t.analyticsSub}</p></div><span className="rounded-full border border-emerald-400/20 bg-emerald-400/5 px-3 py-1.5 text-xs text-emerald-300">{t.realtime}</span></div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label={t.users} value={stats.users.toLocaleString()} delta="+12.4%" />
            <StatCard label={t.sessions} value={stats.sessions.toLocaleString()} delta="+8.1%" />
            <StatCard label={t.events} value={stats.events.toString()} delta="+21.8%" />
            <StatCard label={t.latency} value={`${stats.latency}ms`} delta="-14.2%" />
          </div>
        </div>
      </section>

      <section id="join" className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="grid gap-10 rounded-[2rem] border border-white/10 bg-gradient-to-br from-fuchsia-500/10 to-cyan-400/5 p-7 lg:grid-cols-2 lg:p-12">
          <div><p className="text-sm font-bold uppercase tracking-[.2em] text-fuchsia-300">03</p><h2 className="mt-3 text-4xl font-black">{t.joinTitle}</h2><p className="mt-4 max-w-lg text-slate-400">{t.joinSub}</p></div>
          <form onSubmit={submit} className="space-y-4" noValidate>
            <label className="block"><span className="mb-2 block text-sm font-medium">{t.name}</span><input required minLength={2} value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3.5 outline-none ring-fuchsia-400 focus:ring-2" /></label>
            <label className="block"><span className="mb-2 block text-sm font-medium">{t.email}</span><input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3.5 outline-none ring-fuchsia-400 focus:ring-2" /></label>
            <button className="w-full rounded-2xl bg-white px-5 py-3.5 font-bold text-slate-950 hover:-translate-y-0.5">{t.submit}</button>
            <p role="status" aria-live="polite" className="min-h-6 text-sm text-slate-300">{message}</p>
          </form>
        </div>
      </section>

      <footer className="border-t border-white/10 px-5 py-8">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 text-sm text-slate-500 sm:flex-row"><span>© {new Date().getFullYear()} GlobalPulse</span><span>{t.footer}</span><span className="text-emerald-300">● Systems operational</span></div>
      </footer>
    </main>
  );
}

function Metric({label,value}:{label:string,value:string}){return <div className="rounded-xl bg-white/[.04] p-3"><p className="text-xs text-slate-500">{label}</p><strong className="mt-1 block">{value}</strong></div>}
function StatCard({label,value,delta}:{label:string,value:string,delta:string}){return <div className="rounded-2xl border border-white/10 bg-black/15 p-5"><p className="text-sm text-slate-400">{label}</p><div className="mt-3 flex items-end justify-between"><strong className="text-3xl">{value}</strong><span className="text-xs text-emerald-300">{delta}</span></div></div>}
function Feature({icon,title,body}:{icon:string,title:string,body:string}){return <article className="group rounded-[1.5rem] border border-white/10 bg-white/[.035] p-6 transition hover:-translate-y-1 hover:bg-white/[.06]"><div className="grid size-12 place-items-center rounded-2xl bg-gradient-to-br from-fuchsia-500/20 to-cyan-400/20 text-xl">{icon}</div><h3 className="mt-5 text-xl font-bold">{title}</h3><p className="mt-2 leading-7 text-slate-400">{body}</p></article>}
