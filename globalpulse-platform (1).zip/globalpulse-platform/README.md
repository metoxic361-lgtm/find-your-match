# GlobalPulse

A production-oriented full-stack global website foundation with:

- Next.js + React frontend
- Tailwind CSS
- Express API server
- PostgreSQL schema and indexes
- WebSocket live-pulse channel
- Helmet security headers
- CORS controls
- Rate limiting
- CRUD content endpoints
- User registration endpoint
- Responsive, accessible UI
- English, Swahili, Spanish, French and Arabic UI translations
- Automatic RTL direction for Arabic
- Light/dark theme toggle

## Requirements

Node.js 20+ and PostgreSQL 15+.

## Run locally

1. Create a PostgreSQL database named `globalpulse`.
2. Run `db/schema.sql` against that database.
3. Copy `.env.example` to `.env` and set `DATABASE_URL`.
4. Install packages:

```bash
npm install
```

5. Start:

```bash
npm run dev
```

Open `http://localhost:3000`.

## API

- `GET /api/v1/health`
- `GET /api/v1/stats`
- `GET /api/v1/data`
- `POST /api/v1/users`
- `POST /api/v1/content`
- `PATCH /api/v1/content/:id`
- `DELETE /api/v1/content/:id`
- WebSocket: `/api/v1/ws`

Example user payload:

```json
{
  "name": "Amina Noor",
  "email": "amina@example.com",
  "locale": "sw",
  "timezone": "Africa/Nairobi"
}
```

## Production notes

- Put PostgreSQL behind a managed service with TLS and connection pooling.
- Set a strict `CORS_ORIGIN` to the deployed site origin.
- Put the app behind HTTPS.
- Add a proper authentication provider/session-cookie layer before exposing protected CRUD endpoints.
- Use a managed WebSocket/realtime service when deploying to infrastructure that does not keep custom Node processes alive. The included server is intended for a Node-capable deployment.
- Add observability, backups, migration tooling and secret management before handling sensitive production data.

The UI's global population and website counts are treated as context rather than application data; they should be updated from authoritative sources when used in public marketing copy.
